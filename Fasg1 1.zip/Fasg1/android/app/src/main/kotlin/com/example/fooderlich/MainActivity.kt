package com.example.fooderlich

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
